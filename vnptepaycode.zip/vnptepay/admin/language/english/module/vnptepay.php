<?php
// Heading
$_['heading_title']       = 'VNPTEPAY';
 
// Text
$_['text_module']         	= 'Modules';
$_['text_edit']           	= 'Edit Vnptepay Module';
$_['text_success']        	= 'Success: You have modified module Vnptepay!';
$_['text_ws_url']          	= 'Link Webservice:';
$_['text_partner_name']     = 'Partner Username:';
$_['text_partner_password'] = 'Partner Password:';
$_['text_key_sofpin']       = 'Key Sofpin:';
$_['text_time_out']         = 'Time Out:';
 
// Entry
$_['entry_code']          = 'Vnptepay Code:';
$_['entry_status']        = 'Status:';
 
// Error
$_['error_permission']    = 'Warning: You do not have permission to modify module Vnptepay!';
$_['error_code']          = 'Code Required';